package id.pramana.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var wallpaperView: ImageView
    private lateinit var sidebar: LinearLayout
    private lateinit var mainContent: LinearLayout
    private var wallpaperUri: Uri? = null
    private val blue = Color.rgb(45, 105, 220)
    private val white = Color.WHITE
    private val appButtons = mutableListOf<View>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        val savedWallpaper = getSharedPreferences("pramana", MODE_PRIVATE).getString("wallpaper_uri", null)
        wallpaperUri = savedWallpaper?.let { runCatching { Uri.parse(it) }.getOrNull() }
        buildUi()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun label(text: String, size: Float, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(white)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun button(text: String, icon: String = "", action: () -> Unit): TextView =
        label(if (icon.isEmpty()) text else "$icon   $text", 16f, true).apply {
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = rounded(Color.argb(190, 12, 19, 28), 14)
            isFocusable = true
            isClickable = true
            setOnClickListener { action() }
            setOnFocusChangeListener { v, focused ->
                v.background = rounded(if (focused) blue else Color.argb(190, 12, 19, 28), 14)
            }
        }

    private fun buildUi() {
        root = FrameLayout(this)
        wallpaperView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.rgb(35, 58, 76))
            contentDescription = "Wallpaper"
        }
        root.addView(wallpaperView, FrameLayout.LayoutParams(-1, -1))
        wallpaperUri?.let { wallpaperView.setImageURI(it) }

        val shade = View(this).apply { setBackgroundColor(Color.argb(48, 0, 0, 0)) }
        root.addView(shade, FrameLayout.LayoutParams(-1, -1))

        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(28), dp(12), dp(28), dp(8))
        }
        top.addView(label("PRAMANA LAUNCHER", 18f, true), LinearLayout.LayoutParams(0, dp(44), 1f))
        val mic = button("🎙", "") { launchVoiceSearch() }
        mic.text = "🎙"
        mic.textSize = 28f
        mic.gravity = Gravity.CENTER
        mic.background = rounded(Color.argb(210, 20, 38, 58), 50)
        top.addView(mic, LinearLayout.LayoutParams(dp(62), dp(54)))
        top.addView(label("   ◈   14:32   ", 15f), LinearLayout.LayoutParams(-2, dp(44)))
        page.addView(top)

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(24), dp(8), dp(24), dp(8))
        }
        sidebar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.argb(205, 8, 16, 25), 20)
            setPadding(dp(10), dp(12), dp(10), dp(12))
        }
        val scroll = ScrollView(this)
        val sideItems = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listOf("Home", "YouTube", "YouTube Music", "Netflix", "Plex", "Files", "Wallpaper").forEachIndexed { index, name ->
            val item = button(name, when (name) {
                "Home" -> "⌂"; "YouTube" -> "▶"; "YouTube Music" -> "♫"
                "Netflix" -> "N"; "Plex" -> "▶"; "Files" -> "▣"; else -> "▧"
            }) {
                when (name) {
                    "Home" -> Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show()
                    "Wallpaper" -> chooseWallpaper()
                    else -> launchAppByName(name)
                }
            }
            item.textSize = 15f
            val lp = LinearLayout.LayoutParams(-1, dp(52))
            lp.bottomMargin = dp(5)
            sideItems.addView(item, lp)
            appButtons.add(item)
        }
        scroll.addView(sideItems)
        sidebar.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        body.addView(sidebar, LinearLayout.LayoutParams(dp(252), -1))

        mainContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(20), 0, dp(20), 0)
        }
        val welcome = label("Wallpaper foto sendiri", 24f, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(20), dp(20), dp(20))
            background = rounded(Color.argb(65, 0, 0, 0), 18)
            isFocusable = true
            setOnClickListener { chooseWallpaper() }
        }
        mainContent.addView(welcome, LinearLayout.LayoutParams(-1, dp(100)))
        val hint = label("Pilih Wallpaper di menu kiri untuk menggunakan foto sendiri", 14f)
        hint.gravity = Gravity.CENTER
        mainContent.addView(hint, LinearLayout.LayoutParams(-1, dp(48)))
        body.addView(mainContent, LinearLayout.LayoutParams(0, -1, 1f))
        page.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(4), dp(24), dp(16))
            background = rounded(Color.argb(215, 8, 13, 19), 16)
        }
        listOf("⚙  Settings", "▦  Apps", "⇥  Inputs", "☾  Sleep").forEach { name ->
            val b = button(name) {
                when {
                    name.contains("Apps") -> showApps()
                    name.contains("Settings") -> openSystemSettings()
                    name.contains("Inputs") -> Toast.makeText(this, "Input menu tergantung firmware TV Box", Toast.LENGTH_LONG).show()
                    name.contains("Sleep") -> Toast.makeText(this, "Fungsi Sleep memerlukan dukungan sistem/perangkat", Toast.LENGTH_LONG).show()
                }
            }
            b.gravity = Gravity.CENTER
            bottom.addView(b, LinearLayout.LayoutParams(0, dp(54), 1f))
        }
        page.addView(bottom)
        root.addView(page, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        sidebar.isFocusableInTouchMode = true
        appButtons.firstOrNull()?.requestFocus()
    }

    private fun chooseWallpaper() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try { startActivityForResult(intent, 1001) }
        catch (_: ActivityNotFoundException) { Toast.makeText(this, "Pemilih file tidak tersedia", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Using result API for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            wallpaperUri = uri
            getSharedPreferences("pramana", MODE_PRIVATE).edit().putString("wallpaper_uri", uri.toString()).apply()
            wallpaperView.setImageURI(uri)
        }
    }

    private fun launchVoiceSearch() {
        val intents = listOf(
            Intent("android.intent.action.VOICE_COMMAND").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            Intent("android.intent.action.ASSIST").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        for (intent in intents) {
            try { startActivity(intent); return }
            catch (_: Exception) {}
        }
        Toast.makeText(this, "Google Assistant tidak tersedia melalui intent pada firmware ini. Coba tombol mikrofon remote.", Toast.LENGTH_LONG).show()
    }

    private fun launchAppByName(name: String) {
        val pm = packageManager
        val matches = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val found = matches.firstOrNull { it.loadLabel(pm).toString().equals(name, true) ||
            (name == "Files" && it.loadLabel(pm).toString().contains("file", true)) ||
            (name == "YouTube Music" && it.loadLabel(pm).toString().contains("YouTube Music", true)) }
        if (found != null) {
            val launch = pm.getLaunchIntentForPackage(found.activityInfo.packageName)
            if (launch != null) { startActivity(launch); return }
        }
        Toast.makeText(this, "$name tidak ditemukan. Gunakan Apps untuk melihat aplikasi yang tersedia.", Toast.LENGTH_LONG).show()
    }

    private fun showApps() {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), PackageManager.MATCH_ALL)
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        val names = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
        if (apps.isEmpty()) {
            Toast.makeText(this, "Tidak ada aplikasi yang terdeteksi", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Aplikasi").setItems(names) { _, which ->
            pm.getLaunchIntentForPackage(apps[which].activityInfo.packageName)?.let { startActivity(it) }
        }.setNegativeButton("Tutup", null).show()
    }

    private fun openSystemSettings() {
        try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
        catch (_: Exception) { Toast.makeText(this, "Pengaturan sistem tidak bisa dibuka", Toast.LENGTH_LONG).show() }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) { showApps(); return true }
        if (keyCode == KeyEvent.KEYCODE_SEARCH) { launchVoiceSearch(); return true }
        return super.onKeyDown(keyCode, event)
    }
}
