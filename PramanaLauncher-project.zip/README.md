# Pramana Launcher

Starter Android TV launcher for B866F / Google TV Android 14.

## Build
Requires JDK 17, Android SDK platform 35, and Gradle 8.9. GitHub Actions workflow is provided separately for cloud builds.

## Current starter features
- TV-oriented landscape UI with left sidebar and bottom shortcuts
- Choose a personal image using Android's document picker
- App list dialog
- Best-effort voice/assistant intent launch (firmware dependent)
- Declares both Leanback launcher and Home launcher entry points

## Notes
This is an initial starter project, not a full Google TV replacement. Assistant intents, Inputs, Sleep, and default Home behavior depend on the vendor firmware. The wallpaper picker uses the system document provider; USB browsing depends on the file picker available on the device.
